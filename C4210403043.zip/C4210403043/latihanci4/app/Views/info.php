<?= $this->extend('layout/template'); ?>

<?= $this->section('content'); ?>
<h1>Info Kegiatan</h1>
<p>Informasi kegiatan siswa bulan ini :</p>
<ul>
  <li>10 Agustus - Masa Orientasi Siswa</li>
  <li>17 Agustus - Upacara Kemerdekaan</li>
</ul>
<p>Informasi kegiatan siswa bulan depan :</p>
<ul>
  <li>12 September - Ujian Tengah Semester</li>
</ul>

<?= $this->endSection(); ?>